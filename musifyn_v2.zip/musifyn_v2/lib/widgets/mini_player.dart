import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:just_audio/just_audio.dart';
import '../services/player_service.dart';
import '../services/jellyfin_service.dart';
import '../screens/player_screen.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerService>();
    final track = player.currentTrack;
    if (track == null) return const SizedBox.shrink();
    final jellyfin = context.read<JellyfinService>();

    return GestureDetector(
      onTap: () => Navigator.push(
          context, MaterialPageRoute(builder: (_) => const PlayerScreen())),
      child: Container(
        margin: const EdgeInsets.fromLTRB(8, 0, 8, 4),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFF1A1A1A).withOpacity(0.9),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                    color: const Color(0xFF1DB954).withOpacity(0.25),
                    width: 0.8),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // ── Barre de progression fine ──
                  _ProgressStrip(player: player),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
                    child: Row(
                      children: [
                        // Pochette
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: track.albumId != null
                              ? Image.network(
                                  jellyfin.getImageUrl(track.albumId!, size: 100),
                                  width: 44, height: 44, fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => _placeholder(),
                                )
                              : _placeholder(),
                        ),
                        const SizedBox(width: 10),
                        // Titre + artiste
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(track.name,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis),
                              Text(track.artistName ?? '',
                                  style: TextStyle(
                                      color: Colors.white.withOpacity(0.5),
                                      fontSize: 11),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis),
                            ],
                          ),
                        ),
                        // ── Contrôles ──
                        StreamBuilder<PlayerState>(
                          stream: player.playerStateStream,
                          builder: (ctx, snap) {
                            final playing = snap.data?.playing ?? false;
                            return Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                // Répétition
                                _RepeatButton(player: player),
                                // Précédent
                                _MiniBtn(icon: Icons.skip_previous, onTap: player.skipPrevious),
                                // Play/Pause
                                GestureDetector(
                                  onTap: player.playPause,
                                  child: Container(
                                    width: 38, height: 38,
                                    decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Color(0xFF1DB954)),
                                    child: Icon(
                                        playing ? Icons.pause : Icons.play_arrow,
                                        color: Colors.black, size: 24),
                                  ),
                                ),
                                // Suivant
                                _MiniBtn(icon: Icons.skip_next, onTap: player.skipNext),
                                const SizedBox(width: 2),
                              ],
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _placeholder() => Container(
        width: 44, height: 44,
        decoration: const BoxDecoration(
            color: Color(0xFF1A2A1F),
            borderRadius: BorderRadius.all(Radius.circular(8))),
        child: const Icon(Icons.music_note, color: Color(0xFF1DB954), size: 22),
      );
}

// ── Barre de progression fine cliquable ──
class _ProgressStrip extends StatelessWidget {
  final PlayerService player;
  const _ProgressStrip({required this.player});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Duration>(
      stream: player.positionStream,
      builder: (ctx, posSnap) => StreamBuilder<Duration?>(
        stream: player.durationStream,
        builder: (ctx, durSnap) {
          final pos = posSnap.data ?? Duration.zero;
          final dur = durSnap.data ?? Duration.zero;
          final progress = dur.inMilliseconds > 0
              ? (pos.inMilliseconds / dur.inMilliseconds).clamp(0.0, 1.0)
              : 0.0;

          return GestureDetector(
            onTapDown: (details) {
              final box = context.findRenderObject() as RenderBox?;
              if (box == null || dur == Duration.zero) return;
              final x = (details.localPosition.dx / box.size.width).clamp(0.0, 1.0);
              player.seek(Duration(milliseconds: (x * dur.inMilliseconds).round()));
            },
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 3,
                backgroundColor: Colors.white.withOpacity(0.1),
                valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF1DB954)),
              ),
            ),
          );
        },
      ),
    );
  }
}

// ── Bouton répétition : off → all → one → off ──
class _RepeatButton extends StatelessWidget {
  final PlayerService player;
  const _RepeatButton({required this.player});

  @override
  Widget build(BuildContext context) {
    final mode = player.loopMode;
    final active = mode != LoopMode.off;
    final isOne = mode == LoopMode.one;

    return GestureDetector(
      onTap: player.cycleLoopMode,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 32, height: 32,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Icon(
              isOne ? Icons.repeat_one : Icons.repeat,
              color: active ? const Color(0xFF1DB954) : Colors.white.withOpacity(0.4),
              size: 18,
            ),
            if (active)
              Positioned(
                bottom: 3,
                child: Container(
                  width: 4, height: 4,
                  decoration: const BoxDecoration(
                      shape: BoxShape.circle, color: Color(0xFF1DB954)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ── Bouton icône compact ──
class _MiniBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _MiniBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
          child: Icon(icon, color: Colors.white, size: 22),
        ),
      );
}
