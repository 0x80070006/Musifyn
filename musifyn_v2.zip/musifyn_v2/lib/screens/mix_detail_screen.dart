import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:just_audio/just_audio.dart';
import '../services/player_service.dart';
import '../services/jellyfin_service.dart';
import '../models/media_item_model.dart';
import 'player_screen.dart';

class MixDetailScreen extends StatelessWidget {
  final String mixName;
  final Color mixColor;
  final IconData mixIcon;
  final List<MediaItemModel> tracks;

  const MixDetailScreen({
    super.key,
    required this.mixName,
    required this.mixColor,
    required this.mixIcon,
    required this.tracks,
  });

  @override
  Widget build(BuildContext context) {
    final jf = context.read<JellyfinService>();
    final player = context.watch<PlayerService>();

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: CustomScrollView(
        slivers: [
          // ── Header avec dégradé couleur du mix ──
          SliverAppBar(
            expandedHeight: 240,
            pinned: true,
            backgroundColor: mixColor.withOpacity(0.9),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  // Fond dégradé
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          mixColor,
                          mixColor.withOpacity(0.6),
                          const Color(0xFF0A0A0A),
                        ],
                        stops: const [0.0, 0.6, 1.0],
                      ),
                    ),
                  ),
                  // Icône décorative en fond
                  Positioned(
                    right: -20,
                    top: 10,
                    child: Icon(mixIcon,
                        size: 160,
                        color: Colors.white.withOpacity(0.08)),
                  ),
                  // Contenu
                  Positioned(
                    bottom: 20,
                    left: 20,
                    right: 20,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 70,
                          height: 70,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.3)),
                          ),
                          child: Icon(mixIcon,
                              color: Colors.white, size: 36),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          mixName,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${tracks.length} titre${tracks.length != 1 ? "s" : ""}',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.7),
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ── Boutons Lecture / Aléatoire ──
          SliverToBoxAdapter(
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Row(
                children: [
                  // Bouton Lecture
                  GestureDetector(
                    onTap: () => _playFrom(context, 0),
                    child: Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: mixColor,
                        boxShadow: [
                          BoxShadow(
                            color: mixColor.withOpacity(0.4),
                            blurRadius: 16,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.play_arrow,
                          color: Colors.black, size: 32),
                    ),
                  ),
                  const SizedBox(width: 16),
                  // Bouton Aléatoire
                  GestureDetector(
                    onTap: () => _playShuffled(context),
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.08),
                        border: Border.all(
                            color: Colors.white.withOpacity(0.15)),
                      ),
                      child: Icon(Icons.shuffle,
                          color: Colors.white.withOpacity(0.8), size: 22),
                    ),
                  ),
                  const Spacer(),
                  // Infos
                  Text(
                    'Mix · ${tracks.length} titres',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.4),
                        fontSize: 12),
                  ),
                ],
              ),
            ),
          ),

          // ── Liste des titres ──
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (ctx, i) {
                final track = tracks[i];
                final isPlaying = player.currentTrack?.id == track.id &&
                    player.isPlaying;
                final isCurrent = player.currentTrack?.id == track.id;

                return _TrackRow(
                  track: track,
                  index: i,
                  isPlaying: isPlaying,
                  isCurrent: isCurrent,
                  mixColor: mixColor,
                  jf: jf,
                  onTap: () => _playFrom(context, i),
                );
              },
              childCount: tracks.length,
            ),
          ),

          const SliverToBoxAdapter(child: SizedBox(height: 160)),
        ],
      ),
    );
  }

  void _playFrom(BuildContext context, int index) {
    final jf = context.read<JellyfinService>();
    final streamTracks = tracks
        .map((t) => MediaItemModel(
              id: t.id,
              name: t.name,
              type: t.type,
              serverUrl: jf.getStreamUrl(t.id),
              artistName: t.artistName,
              albumName: t.albumName,
              albumId: t.albumId,
              durationMs: t.durationMs,
            ))
        .toList();

    context
        .read<PlayerService>()
        .playTrack(streamTracks[index], queue: streamTracks, index: index);
    Navigator.push(
        context, MaterialPageRoute(builder: (_) => const PlayerScreen()));
  }

  void _playShuffled(BuildContext context) {
    final jf = context.read<JellyfinService>();
    final shuffled = List.of(tracks)..shuffle();
    final streamTracks = shuffled
        .map((t) => MediaItemModel(
              id: t.id,
              name: t.name,
              type: t.type,
              serverUrl: jf.getStreamUrl(t.id),
              artistName: t.artistName,
              albumName: t.albumName,
              albumId: t.albumId,
              durationMs: t.durationMs,
            ))
        .toList();

    final player = context.read<PlayerService>();
    player.playTrack(streamTracks.first, queue: streamTracks, index: 0);
    Navigator.push(
        context, MaterialPageRoute(builder: (_) => const PlayerScreen()));
  }
}

class _TrackRow extends StatelessWidget {
  final MediaItemModel track;
  final int index;
  final bool isPlaying;
  final bool isCurrent;
  final Color mixColor;
  final JellyfinService jf;
  final VoidCallback onTap;

  const _TrackRow({
    required this.track,
    required this.index,
    required this.isPlaying,
    required this.isCurrent,
    required this.mixColor,
    required this.jf,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        color: isCurrent
            ? mixColor.withOpacity(0.08)
            : Colors.transparent,
        padding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          children: [
            // Numéro ou animation lecture
            SizedBox(
              width: 32,
              child: isCurrent
                  ? _PlayingIndicator(color: mixColor, playing: isPlaying)
                  : Text(
                      '${index + 1}',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.35),
                        fontSize: 14,
                      ),
                      textAlign: TextAlign.center,
                    ),
            ),
            const SizedBox(width: 12),
            // Pochette
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: track.albumId != null
                  ? Image.network(
                      jf.getImageUrl(track.albumId!, size: 80),
                      width: 44,
                      height: 44,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _placeholder(),
                    )
                  : _placeholder(),
            ),
            const SizedBox(width: 12),
            // Titre + artiste
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    track.name,
                    style: TextStyle(
                      color: isCurrent ? mixColor : Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    track.artistName ?? '',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.45),
                      fontSize: 12,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            // Durée
            if (track.durationMs != null)
              Text(
                _fmt(Duration(milliseconds: track.durationMs!)),
                style: TextStyle(
                  color: Colors.white.withOpacity(0.35),
                  fontSize: 12,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _placeholder() {
    return Container(
      width: 44,
      height: 44,
      color: mixColor.withOpacity(0.2),
      child: Icon(Icons.music_note, color: mixColor, size: 20),
    );
  }

  String _fmt(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }
}

// Petite animation "en lecture" (3 barres qui pulsent)
class _PlayingIndicator extends StatefulWidget {
  final Color color;
  final bool playing;
  const _PlayingIndicator({required this.color, required this.playing});

  @override
  State<_PlayingIndicator> createState() => _PlayingIndicatorState();
}

class _PlayingIndicatorState extends State<_PlayingIndicator>
    with TickerProviderStateMixin {
  late List<AnimationController> _controllers;
  late List<Animation<double>> _anims;

  @override
  void initState() {
    super.initState();
    _controllers = List.generate(
      3,
      (i) => AnimationController(
        vsync: this,
        duration: Duration(milliseconds: 400 + i * 120),
      ),
    );
    _anims = _controllers
        .map((c) => Tween(begin: 0.3, end: 1.0).animate(
              CurvedAnimation(parent: c, curve: Curves.easeInOut),
            ))
        .toList();
    if (widget.playing) {
      for (final c in _controllers) {
        c.repeat(reverse: true);
      }
    }
  }

  @override
  void didUpdateWidget(_PlayingIndicator old) {
    super.didUpdateWidget(old);
    if (widget.playing != old.playing) {
      if (widget.playing) {
        for (final c in _controllers) c.repeat(reverse: true);
      } else {
        for (final c in _controllers) c.stop();
      }
    }
  }

  @override
  void dispose() {
    for (final c in _controllers) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: List.generate(3, (i) {
        return AnimatedBuilder(
          animation: _anims[i],
          builder: (_, __) => Container(
            width: 3,
            height: 14 * _anims[i].value,
            margin: const EdgeInsets.symmetric(horizontal: 1),
            decoration: BoxDecoration(
              color: widget.color,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        );
      }),
    );
  }
}
